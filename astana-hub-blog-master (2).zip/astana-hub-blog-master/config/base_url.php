<?php
    $BASE_URL = "http://localhost/astana-hub";
?>